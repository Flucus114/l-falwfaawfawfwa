package com.classselector;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

/** Editor de classe (só aparece para OPs). */
public class ClassEditScreen extends Screen {
    private final Screen parent;
    private final ClassDef orig;
    private EditBox id, name, desc, abil, icon;

    public ClassEditScreen(Screen parent, ClassDef orig) {
        super(Component.literal(orig == null ? "Nova classe" : "Editar classe"));
        this.parent = parent;
        this.orig = orig;
    }

    private EditBox mk(int x, int y, int w, String val) {
        EditBox b = new EditBox(font, x, y, w, 18, Component.empty());
        b.setMaxLength(256);
        b.setValue(val);
        addRenderableWidget(b);
        return b;
    }

    @Override
    protected void init() {
        int x = width / 2 - 150, y = Math.max(12, height / 2 - 112);
        id = mk(x, y + 22, 300, orig == null ? "" : orig.id);
        id.setEditable(orig == null);
        name = mk(x, y + 54, 300, orig == null ? "" : orig.name);
        desc = mk(x, y + 86, 300, orig == null ? "" : orig.description);
        abil = mk(x, y + 118, 300, orig == null ? "" : String.join("; ", orig.abilities));
        icon = mk(x, y + 150, 200, orig == null ? "minecraft:iron_sword" : orig.icon);

        addRenderableWidget(Button.builder(Component.literal("Item na mão"), b -> {
            ItemStack held = minecraft.player.getMainHandItem();
            if (!held.isEmpty()) icon.setValue(ForgeRegistries.ITEMS.getKey(held.getItem()).toString());
        }).bounds(x + 204, y + 149, 96, 20).build());

        int by = y + 178;
        addRenderableWidget(Button.builder(Component.literal("Salvar"), b -> { if (save()) onClose(); })
                .bounds(x, by, 148, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Salvar e editar itens"), b -> {
            if (save()) Net.CH.sendToServer(new Net.EditItems(ClassDef.sanitize(id.getValue())));
        }).bounds(x + 152, by, 148, 20).build());
        Button del = addRenderableWidget(Button.builder(Component.literal("Excluir"), b -> {
            Net.CH.sendToServer(new Net.Delete(orig.id));
            onClose();
        }).bounds(x, by + 24, 148, 20).build());
        del.active = orig != null;
        addRenderableWidget(Button.builder(Component.literal("Voltar"), b -> onClose())
                .bounds(x + 152, by + 24, 148, 20).build());
    }

    private boolean save() {
        String cid = ClassDef.sanitize(id.getValue());
        if (cid.isEmpty() || name.getValue().isBlank()) return false;
        ClassDef d = new ClassDef();
        d.id = cid;
        d.name = name.getValue().trim();
        d.description = desc.getValue().trim();
        d.icon = icon.getValue().trim();
        for (String s : abil.getValue().split(";")) if (!s.isBlank()) d.abilities.add(s.trim());
        if (orig != null) d.items = orig.items;
        Net.CH.sendToServer(new Net.Save(d.save()));
        return true;
    }

    @Override
    public void onClose() { minecraft.setScreen(parent); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int x = width / 2 - 150, y = Math.max(12, height / 2 - 112);
        g.drawCenteredString(font, title, width / 2, y, 0xFFFFFF);
        g.drawString(font, "ID (letras minúsculas, números e _)", x, y + 12, 0xFFAAAAAA, false);
        g.drawString(font, "Nome", x, y + 44, 0xFFAAAAAA, false);
        g.drawString(font, "Descrição", x, y + 76, 0xFFAAAAAA, false);
        g.drawString(font, "Habilidades (separe com ;)", x, y + 108, 0xFFAAAAAA, false);
        g.drawString(font, "Ícone (id do item)", x, y + 140, 0xFFAAAAAA, false);
        super.render(g, mx, my, pt);
    }
}
