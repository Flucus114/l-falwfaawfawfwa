package com.classselector;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.Brain;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.memory.WalkTarget;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.UUID;

/**
 * Warden domado com o Olho Cósmico: guarda o dono, nunca ataca o dono, segue o dono,
 * ataca monstros hostis e quem o dono atacou ou quem atacou o dono.
 */
@Mod.EventBusSubscriber(modid = ClassSelectorMod.MODID)
public class TamedWarden {
    public static final String KEY = "classselector_owner";
    /** Chance (0 a 1) de o Olho Cósmico domar o Warden. */
    public static final float TAME_CHANCE = 0.10F;

    public static boolean isTamed(Warden w) {
        return w.getPersistentData().hasUUID(KEY);
    }

    public static UUID ownerId(Warden w) {
        return isTamed(w) ? w.getPersistentData().getUUID(KEY) : null;
    }

    public static void tame(Warden w, Player p) {
        w.getPersistentData().putUUID(KEY, p.getUUID());
        w.setPersistenceRequired();
        w.setCustomName(Component.literal("Warden de " + p.getName().getString()));
        w.setCustomNameVisible(true);
        w.getBrain().eraseMemory(MemoryModuleType.ATTACK_TARGET);
        w.getAngerManagement().clearAnger(p);
        if (w.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.HEART, w.getX(), w.getY() + w.getBbHeight() * 0.8, w.getZ(),
                    14, 0.6, 0.6, 0.6, 0.02);
            sl.playSound(null, w.blockPosition(), SoundEvents.WARDEN_LISTENING, SoundSource.NEUTRAL, 1.0F, 1.0F);
        }
        p.displayClientMessage(Component.literal("Você domou o Warden!"), true);
    }

    /** Falha ao domar: o Warden resiste e fica furioso com quem tentou. */
    public static void failTame(Warden w, Player p) {
        if (w.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.ANGRY_VILLAGER, w.getX(), w.getY() + w.getBbHeight() * 0.8, w.getZ(),
                    10, 0.6, 0.6, 0.6, 0.02);
        }
        p.displayClientMessage(Component.literal("O Warden resistiu ao Olho Cósmico!"), true);
        w.increaseAngerAt(p, 150, true);
    }

    /** Clique direito no Warden domado (dono) abre o menu de equipamento. */
    @SubscribeEvent
    public static void onInteract(PlayerInteractEvent.EntityInteract e) {
        if (!(e.getTarget() instanceof Warden w) || !isTamed(w) || e.getHand() != InteractionHand.MAIN_HAND) return;
        if (e.getItemStack().getItem() instanceof CosmicEyeItem) return;
        Player p = e.getEntity();
        if (!p.getUUID().equals(ownerId(w))) return;
        e.setCanceled(true);
        e.setCancellationResult(InteractionResult.sidedSuccess(p.level().isClientSide));
        if (p instanceof ServerPlayer sp) {
            NetworkHooks.openScreen(sp,
                    new SimpleMenuProvider((id, inv, pl) -> new WardenMenu(id, inv, w), w.getDisplayName()),
                    buf -> buf.writeVarInt(w.getId()));
        }
    }

    private static boolean recent(Player owner, LivingEntity t) {
        if (owner == null || t == null) return false;
        if (t == owner.getLastHurtByMob() && owner.tickCount - owner.getLastHurtByMobTimestamp() < 200) return true;
        return t == owner.getLastHurtMob() && owner.tickCount - owner.getLastHurtMobTimestamp() < 200;
    }

    private static boolean allowed(Player owner, LivingEntity t) {
        if (owner != null && t == owner) return false;
        return t instanceof Enemy || recent(owner, t);
    }

    @SubscribeEvent
    public static void onTick(LivingEvent.LivingTickEvent e) {
        if (!(e.getEntity() instanceof Warden w) || w.level().isClientSide || !isTamed(w)) return;
        ServerLevel lv = (ServerLevel) w.level();
        Player owner = lv.getPlayerByUUID(ownerId(w));
        Brain<Warden> brain = w.getBrain();

        // 1) só ataca o que é permitido (nunca o dono)
        LivingEntity target = brain.getMemory(MemoryModuleType.ATTACK_TARGET).orElse(null);
        if (target != null && !allowed(owner, target)) {
            brain.eraseMemory(MemoryModuleType.ATTACK_TARGET);
            w.getAngerManagement().clearAnger(target);
            target = null;
        }
        if (owner == null || owner.level() != w.level()) return;

        // 2) defende o dono
        if (target == null && w.tickCount % 10 == 0) {
            LivingEntity a = owner.getLastHurtByMob();
            LivingEntity b = owner.getLastHurtMob();
            LivingEntity pick = recent(owner, a) ? a : (recent(owner, b) ? b : null);
            if (pick != null && pick != owner && pick.isAlive() && w.canTargetEntity(pick)) {
                w.increaseAngerAt(pick, 150, false);
            }
        }

        // 3) segue o dono quando não está lutando
        if (target == null && w.tickCount % 20 == 0) {
            double d2 = w.distanceToSqr(owner);
            if (d2 > 40 * 40) {
                w.moveTo(owner.getX(), owner.getY(), owner.getZ(), w.getYRot(), w.getXRot());
                w.getNavigation().stop();
            } else if (d2 > 8 * 8) {
                brain.setMemory(MemoryModuleType.WALK_TARGET, new WalkTarget(owner, 1.0F, 4));
            }
        }
    }

    /** Segurança extra: o Warden domado nunca machuca o dono. */
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent e) {
        if (e.getSource().getEntity() instanceof Warden w && isTamed(w)
                && e.getEntity().getUUID().equals(ownerId(w))) {
            e.setCanceled(true);
        }
    }
}
