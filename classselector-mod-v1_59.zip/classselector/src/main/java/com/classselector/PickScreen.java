package com.classselector;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.List;

/**
 * Base das telas de seleção (classe e raça): moldura cinza, lista à esquerda, medalhão com o item no centro
 * e detalhes + botão à direita. Tudo desenhado por código (sem texturas).
 */
public abstract class PickScreen extends Screen {
    /** Dados de uma opção (classe ou raça) já prontos para desenhar. */
    public record Entry(String id, String name, ItemStack icon, String desc,
                        String linesTitle, List<String> lines, boolean signed,
                        String itemsTitle, List<ItemStack> items) {}

    private static final int[] TINTS = {0xFF3B3B40, 0xFF1F3A6E, 0xFF5A3B1C, 0xFF6E1F2A, 0xFF6B5416, 0xFF7A1F1F};
    private static final int C_TEXT = 0xFFEDEDF0, C_SUB = 0xFF8E8E96, C_BODY = 0xFFC4C4CC;
    private static final int C_GOLD = 0xFFE8B83A, C_GREEN = 0xFF66E066, C_RED = 0xFFFF5F5F;
    private static final int C_DARK = 0xFF0E0E10, C_COL = 0xFF161619;

    protected final boolean forced;
    private final String header, chooseLabel;
    private String selected;
    private int scroll;
    private int px, py, pw, ph, bx, by, bw, bh, lw, rw;
    private ItemStack hoverStack = ItemStack.EMPTY;

    protected PickScreen(Component title, String header, String chooseLabel, boolean forced) {
        super(title);
        this.header = header;
        this.chooseLabel = chooseLabel;
        this.forced = forced;
    }

    protected abstract List<Entry> entries();
    protected abstract void choose(String id);
    /** id == null: criar nova. */
    protected abstract void edit(String id);
    protected abstract String emptyText();

    @Override
    protected void init() {
        boolean op = ClientState.op;
        pw = Math.min(width - 12, 420);
        ph = Math.min(height - (op ? 56 : 12), 240);
        px = (width - pw) / 2;
        py = (height - ph - (op ? 26 : 0)) / 2;
        bx = px + 5;
        by = py + 28;
        bw = pw - 10;
        bh = ph - 33;
        lw = Mth.clamp(bw * 30 / 100, 96, 130);
        rw = Mth.clamp(bw * 32 / 100, 112, 150);

        if (op) {
            int y = py + ph + 6;
            addRenderableWidget(Button.builder(Component.literal("+ Nova"), b -> edit(null))
                    .bounds(px, y, 60, 20).build());
            addRenderableWidget(Button.builder(Component.literal("Editar"), b -> {
                if (selected != null) edit(selected);
            }).bounds(px + 64, y, 60, 20).build());
        }
    }

    @Override
    public boolean shouldCloseOnEsc() { return !forced; }

    @Override
    public boolean isPauseScreen() { return false; }

    private Entry find(List<Entry> list, String id) {
        if (id == null) return null;
        for (Entry e : list) if (e.id().equals(id)) return e;
        return null;
    }

    private int rows() { return Math.max(1, (bh - 8) / 34); }

    // ---------- primitivas ----------
    private static void outline(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x, y, x + w, y + 1, c);
        g.fill(x, y + h - 1, x + w, y + h, c);
        g.fill(x, y, x + 1, y + h, c);
        g.fill(x + w - 1, y, x + w, y + h, c);
    }

    private static void fillCircle(GuiGraphics g, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int half = (int) Math.sqrt((double) r * r - (double) dy * dy);
            g.fill(cx - half, cy + dy, cx + half + 1, cy + dy + 1, color);
        }
    }

    private static void ring(GuiGraphics g, int cx, int cy, int r, int color, int stepDeg) {
        for (int a = 0; a < 360; a += stepDeg) {
            double rad = Math.toRadians(a);
            int x = cx + (int) Math.round(Math.cos(rad) * r);
            int y = cy + (int) Math.round(Math.sin(rad) * r);
            g.fill(x, y, x + 1, y + 1, color);
        }
    }

    private static void diamond(GuiGraphics g, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int half = r - Math.abs(dy);
            g.fill(cx - half, cy + dy, cx + half + 1, cy + dy + 1, color);
        }
    }

    private static void bracket(GuiGraphics g, int x, int y, int sx, int sy, int len, int color) {
        g.fill(Math.min(x, x + sx * len), y, Math.max(x, x + sx * len) + 1, y + 1, color);
        g.fill(x, Math.min(y, y + sy * len), x + 1, Math.max(y, y + sy * len) + 1, color);
    }

    private int wrap(GuiGraphics g, String text, int x, int y, int w, int color, int maxLines) {
        List<FormattedCharSequence> ls = font.split(Component.literal(text), w);
        for (int i = 0; i < ls.size() && i < maxLines; i++) {
            g.drawString(font, ls.get(i), x, y, color, false);
            y += 10;
        }
        return y;
    }

    // ---------- desenho ----------
    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        hoverStack = ItemStack.EMPTY;
        List<Entry> list = entries();
        Entry sel = find(list, selected);
        if (sel == null && !list.isEmpty()) { sel = list.get(0); selected = sel.id(); }

        // moldura cinza com relevo
        g.fill(px, py, px + pw, py + ph, C_DARK);
        g.fill(px + 1, py + 1, px + pw - 1, py + ph - 1, 0xFFA6A6AA);
        g.fill(px + 1, py + 1, px + pw - 1, py + 2, 0xFFCDCDD1);
        g.fill(px + 1, py + 1, px + 2, py + ph - 1, 0xFFCDCDD1);
        g.fill(px + 1, py + ph - 2, px + pw - 1, py + ph - 1, 0xFF77777B);
        g.fill(px + pw - 2, py + 1, px + pw - 1, py + ph - 1, 0xFF77777B);

        // título
        g.renderItem(new ItemStack(Items.BOOK), px + 9, py + 5);
        g.pose().pushPose();
        g.pose().translate(px + 32, py + 9, 0);
        g.pose().scale(1.25f, 1.25f, 1f);
        g.drawString(font, header, 0, 0, 0xFF3A3A3E, false);
        g.pose().popPose();

        // corpo escuro e colunas
        g.fill(bx - 1, by - 1, bx + bw + 1, by + bh + 1, C_DARK);
        g.fill(bx, by, bx + bw, by + bh, C_COL);
        int divA = bx + lw, cx0 = divA + 1, cw = bw - lw - rw - 2, divB = cx0 + cw, rx = divB + 1;
        g.fill(divA, by, divA + 1, by + bh, C_DARK);
        g.fill(divB, by, divB + 1, by + bh, C_DARK);

        drawList(g, mx, my, list);
        drawCenter(g, cx0, cw, sel);
        drawDetails(g, mx, my, rx, sel);

        super.render(g, mx, my, pt);
        if (!hoverStack.isEmpty()) g.renderTooltip(font, hoverStack, mx, my);
        if (ClientState.op)
            g.drawString(font, "Botão direito numa opção = editar", px + 132, py + ph + 12, 0xFF888888, false);
    }

    private void drawList(GuiGraphics g, int mx, int my, List<Entry> list) {
        int rows = rows();
        scroll = Mth.clamp(scroll, 0, Math.max(0, list.size() - rows));
        for (int i = 0; i < rows && scroll + i < list.size(); i++) {
            Entry e = list.get(scroll + i);
            int ex = bx + 4, ey = by + 4 + i * 34, ew = lw - 8 - (list.size() > rows ? 4 : 0);
            boolean on = e.id().equals(selected);
            boolean hov = mx >= ex && mx < ex + ew && my >= ey && my < ey + 30;
            g.fill(ex, ey, ex + ew, ey + 30, on ? 0xFF26262B : 0xFF1C1C20);
            outline(g, ex, ey, ew, 30, on ? C_GOLD : hov ? 0xFF5A5A62 : 0xFF0B0B0D);
            if (on) outline(g, ex + 1, ey + 1, ew - 2, 28, C_GOLD);
            // ícone com fundo colorido
            g.fill(ex + 2, ey + 2, ex + 28, ey + 28, TINTS[(scroll + i) % TINTS.length]);
            outline(g, ex + 2, ey + 2, 26, 26, 0xFF0B0B0D);
            g.renderItem(e.icon(), ex + 7, ey + 7);
            g.drawString(font, font.plainSubstrByWidth(e.name(), ew - 38), ex + 34, ey + 11,
                    on ? C_TEXT : C_BODY, false);
        }
        if (list.isEmpty()) g.drawString(font, emptyText(), bx + 8, by + 8, C_SUB, false);
        if (list.size() > rows) { // barra de rolagem
            int tx = bx + lw - 5, th = bh - 8;
            g.fill(tx, by + 4, tx + 2, by + 4 + th, 0xFF0B0B0D);
            int thumb = Math.max(10, th * rows / list.size());
            int ty = by + 4 + (th - thumb) * scroll / Math.max(1, list.size() - rows);
            g.fill(tx, ty, tx + 2, ty + thumb, 0xFF6A6A72);
        }
    }

    private void drawCenter(GuiGraphics g, int x0, int w, Entry sel) {
        g.fill(x0, by, x0 + w, by + bh, 0xFF19191C);
        int ccx = x0 + w / 2, ccy = by + bh / 2;
        // moldura ornamental
        int fx = x0 + 6, fy = by + 6, fw = w - 12, fh = bh - 12;
        outline(g, fx - 1, fy - 1, fw + 2, fh + 2, 0xFF222226);
        int br = 0xFF4A4636;
        bracket(g, fx + 3, fy + 3, 1, 1, 12, br);
        bracket(g, fx + fw - 4, fy + 3, -1, 1, 12, br);
        bracket(g, fx + 3, fy + fh - 4, 1, -1, 12, br);
        bracket(g, fx + fw - 4, fy + fh - 4, -1, -1, 12, br);

        int R = Mth.clamp(Math.min(w, bh) / 2 - 26, 16, 46);
        // linhas em cruz e diagonais
        int lc = 0xFF2C2A24;
        g.fill(fx + 10, ccy, fx + fw - 10, ccy + 1, lc);
        g.fill(ccx, fy + 10, ccx + 1, fy + fh - 10, lc);
        for (int t = R + 12; t < R + 30; t++) {
            int d = (int) Math.round(t * 0.7071);
            g.fill(ccx + d, ccy + d, ccx + d + 1, ccy + d + 1, lc);
            g.fill(ccx - d, ccy + d, ccx - d + 1, ccy + d + 1, lc);
            g.fill(ccx + d, ccy - d, ccx + d + 1, ccy - d + 1, lc);
            g.fill(ccx - d, ccy - d, ccx - d + 1, ccy - d + 1, lc);
        }
        // medalhão
        fillCircle(g, ccx, ccy, R, 0xFF222226);
        ring(g, ccx, ccy, R, 0xFF5A5038, 3);
        ring(g, ccx, ccy, R + 7, 0xFF3E3A2C, 9);
        int dm = 0xFF6A5A30;
        diamond(g, ccx, ccy - R - 7, 3, dm);
        diamond(g, ccx, ccy + R + 7, 3, dm);
        diamond(g, ccx - R - 7, ccy, 3, dm);
        diamond(g, ccx + R + 7, ccy, 3, dm);

        if (sel != null) { // o item da classe/raça, grande, no meio
            int s = R >= 36 ? 4 : R >= 24 ? 3 : 2;
            g.pose().pushPose();
            g.pose().translate(ccx - 8 * s, ccy - 8 * s, 0);
            g.pose().scale(s, s, 1f);
            g.renderItem(sel.icon(), 0, 0);
            g.pose().popPose();
        }
    }

    private void drawDetails(GuiGraphics g, int mx, int my, int rx, Entry sel) {
        int x = rx + 6, w = rw - 12;
        g.fill(rx, by, rx + rw, by + bh, 0xFF18181B);
        int btnY = by + bh - 26;

        if (sel == null) {
            wrap(g, emptyText(), x, by + 8, w, C_SUB, 3);
            return;
        }

        // banner (pôr do sol desenhado por código) com o item em pé
        int bannerH = Mth.clamp(bh / 4, 30, 56);
        int x1 = rx + 4, y1 = by + 4, x2 = rx + rw - 4, y2 = y1 + bannerH;
        int horizon = y1 + bannerH * 70 / 100;
        g.fillGradient(x1, y1, x2, horizon, 0xFF2B2450, 0xFFD2702C);
        fillCircle(g, x1 + (x2 - x1) * 72 / 100, horizon, 6, 0xFFFFC66B);
        g.fill(x1, horizon, x2, y2, 0xFF17110F);
        int tw = Math.max(5, (x2 - x1) / 14);
        g.fill(x2 - 4 * tw, horizon - 12, x2 - 3 * tw, horizon, 0xFF120D0C);
        g.fill(x2 - 3 * tw - 2, horizon - 18, x2 - 2 * tw - 2, horizon, 0xFF120D0C);
        g.fill(x2 - 2 * tw - 4, horizon - 9, x2 - tw - 4, horizon, 0xFF120D0C);
        outline(g, x1 - 1, y1 - 1, x2 - x1 + 2, bannerH + 2, 0xFF0B0B0D);
        float bs = bannerH >= 46 ? 2f : 1f;
        g.pose().pushPose();
        g.pose().translate(x1 + 10, y2 - 16 * bs - 1, 0);
        g.pose().scale(bs, bs, 1f);
        g.renderItem(sel.icon(), 0, 0);
        g.pose().popPose();

        int y = y2 + 6;
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(1.3f, 1.3f, 1f);
        g.drawString(font, font.plainSubstrByWidth(sel.name(), (int) (w / 1.3f)), 0, 0, C_TEXT, false);
        g.pose().popPose();
        y += 16;

        y = wrap(g, sel.desc(), x, y, w, C_BODY, bh < 150 ? 3 : 4);
        y += 3;
        // divisor com losango
        g.fill(x, y + 3, x + w / 2 - 6, y + 4, 0xFF34343A);
        g.fill(x + w / 2 + 6, y + 3, x + w, y + 4, 0xFF34343A);
        diamond(g, x + w / 2, y + 3, 3, 0xFF5E5E66);
        y += 10;

        int itemsH = sel.items().isEmpty() ? 0 : 28;
        int limit = btnY - 4 - itemsH;
        if (!sel.lines().isEmpty() && y + 10 <= limit) {
            g.drawString(font, sel.linesTitle(), x, y, C_SUB, false);
            y += 10;
            for (String s : sel.lines()) {
                if (y + 10 > limit) break;
                int color = C_BODY;
                String txt = s;
                if (sel.signed()) color = s.startsWith("-") ? C_RED : s.startsWith("+") ? C_GREEN : C_BODY;
                else txt = "• " + s;
                g.drawString(font, font.plainSubstrByWidth(txt, w), x, y, color, false);
                y += 10;
            }
        }
        if (itemsH > 0) {
            int iy = btnY - itemsH + 2;
            g.drawString(font, sel.itemsTitle(), x, iy, C_SUB, false);
            int maxIcons = Math.max(1, w / 18);
            for (int i = 0; i < Math.min(maxIcons, sel.items().size()); i++) {
                int ix = x + i * 18;
                ItemStack s = sel.items().get(i);
                g.renderItem(s, ix, iy + 10);
                g.renderItemDecorations(font, s, ix, iy + 10);
                if (mx >= ix && mx < ix + 16 && my >= iy + 10 && my < iy + 26) hoverStack = s;
            }
        }

        // botão de selecionar
        boolean hov = mx >= x && mx < x + w && my >= btnY && my < btnY + 20;
        g.fill(x, btnY, x + w, btnY + 20, hov ? 0xFF4A4C54 : 0xFF3A3C42);
        outline(g, x, btnY, w, 20, hov ? 0xFF9A9DA6 : 0xFF6B6E76);
        g.fill(x + 1, btnY + 1, x + w - 1, btnY + 2, 0xFF55585F);
        g.drawCenteredString(font, chooseLabel, x + w / 2, btnY + 6, 0xFFFFFFFF);
    }

    // ---------- entrada ----------
    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        List<Entry> list = entries();
        int rows = rows();
        for (int i = 0; i < rows && scroll + i < list.size(); i++) {
            int ex = bx + 4, ey = by + 4 + i * 34, ew = lw - 8;
            if (mx >= ex && mx < ex + ew && my >= ey && my < ey + 30) {
                Entry e = list.get(scroll + i);
                if (button == 0) { selected = e.id(); return true; }
                if (button == 1 && ClientState.op) { selected = e.id(); edit(e.id()); return true; }
            }
        }
        if (button == 0 && selected != null && find(list, selected) != null) {
            int rx = bx + lw + (bw - lw - rw - 2) + 2, x = rx + 6, w = rw - 12, btnY = by + bh - 26;
            if (mx >= x && mx < x + w && my >= btnY && my < btnY + 20) {
                choose(selected);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        scroll -= (int) Math.signum(delta);
        return true;
    }
}
