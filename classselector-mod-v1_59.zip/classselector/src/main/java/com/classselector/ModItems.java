package com.classselector;

import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, ClassSelectorMod.MODID);

    /** Sem receita, sem loot e fora das abas criativas: só via /give até você definir como obter. */
    public static final RegistryObject<Item> COSMIC_EYE = ITEMS.register("cosmic_eye", CosmicEyeItem::new);
}
