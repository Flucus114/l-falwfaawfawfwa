package com.classselector;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Supplier;

/** Pacotes da árvore de habilidades (usa o mesmo canal de Net). */
public class SkillNet {
    public static void register() {
        int i = 40;
        Net.CH.registerMessage(i++, SSync.class, SSync::enc, SSync::dec, SSync::handle);
        Net.CH.registerMessage(i++, SSaveTree.class, SSaveTree::enc, SSaveTree::dec, SSaveTree::handle);
        Net.CH.registerMessage(i++, SDeleteTree.class, SDeleteTree::enc, SDeleteTree::dec, SDeleteTree::handle);
        Net.CH.registerMessage(i++, SSaveSkill.class, SSaveSkill::enc, SSaveSkill::dec, SSaveSkill::handle);
        Net.CH.registerMessage(i++, SDeleteSkill.class, SDeleteSkill::enc, SDeleteSkill::dec, SDeleteSkill::handle);
        Net.CH.registerMessage(i++, SEditRewards.class, SEditRewards::enc, SEditRewards::dec, SEditRewards::handle);
        Net.CH.registerMessage(i++, SUnlock.class, SUnlock::enc, SUnlock::dec, SUnlock::handle);
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private static void cascadeClass(SkillData d, String parentId, String classId) {
        for (SkillDef x : d.skills.values()) {
            if (x.parent.equals(parentId) && !x.classId.equals(classId)) {
                x.classId = classId;
                cascadeClass(d, x.id, classId);
            }
        }
    }

    // ---------- servidor -> cliente ----------
    public record SSync(boolean open, CompoundTag data) {
        static void enc(SSync m, FriendlyByteBuf b) { b.writeBoolean(m.open); b.writeNbt(m.data); }
        static SSync dec(FriendlyByteBuf b) { return new SSync(b.readBoolean(), b.readNbt()); }
        static void handle(SSync m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                    () -> () -> ClientHooks.skillSync(m.open, m.data)));
            c.get().setPacketHandled(true);
        }
    }

    // ---------- cliente -> servidor: qualquer jogador ----------
    public record SUnlock(String id) {
        static void enc(SUnlock m, FriendlyByteBuf b) { b.writeUtf(m.id, 64); }
        static SUnlock dec(FriendlyByteBuf b) { return new SUnlock(b.readUtf(64)); }
        static void handle(SUnlock m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p != null) SkillManager.unlock(p, m.id);
            });
            c.get().setPacketHandled(true);
        }
    }

    // ---------- cliente -> servidor: só OP ----------
    public record SSaveTree(CompoundTag tree) {
        static void enc(SSaveTree m, FriendlyByteBuf b) { b.writeNbt(m.tree); }
        static SSaveTree dec(FriendlyByteBuf b) { return new SSaveTree(b.readNbt()); }
        static void handle(SSaveTree m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null || !p.hasPermissions(2)) return;
                QuestTabDef t = QuestTabDef.load(m.tree);
                t.id = ClassDef.sanitize(t.id);
                if (t.id.isEmpty() || t.name.isBlank()) return;
                if (t.name.length() > 30) t.name = t.name.substring(0, 30);
                SkillData d = SkillData.get(p.server);
                QuestTabDef prev = d.trees.get(t.id);
                if (!t.classId.isEmpty() && !ClassData.get(p.server).classes.containsKey(t.classId)
                        && !(prev != null && prev.classId.equals(t.classId))) t.classId = "";
                d.trees.put(t.id, t);
                d.setDirty();
                SkillManager.syncAll(p.server);
            });
            c.get().setPacketHandled(true);
        }
    }

    public record SDeleteTree(String id) {
        static void enc(SDeleteTree m, FriendlyByteBuf b) { b.writeUtf(m.id, 64); }
        static SDeleteTree dec(FriendlyByteBuf b) { return new SDeleteTree(b.readUtf(64)); }
        static void handle(SDeleteTree m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null || !p.hasPermissions(2)) return;
                SkillData d = SkillData.get(p.server);
                if (d.trees.remove(m.id) == null) return;
                d.skills.values().removeIf(s -> s.tree.equals(m.id)); // apaga as skills da árvore
                d.setDirty();
                SkillManager.syncAll(p.server);
            });
            c.get().setPacketHandled(true);
        }
    }

    public record SSaveSkill(CompoundTag skill) {
        static void enc(SSaveSkill m, FriendlyByteBuf b) { b.writeNbt(m.skill); }
        static SSaveSkill dec(FriendlyByteBuf b) { return new SSaveSkill(b.readNbt()); }
        static void handle(SSaveSkill m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null || !p.hasPermissions(2)) return;
                SkillData d = SkillData.get(p.server);
                SkillDef s = SkillDef.load(m.skill);
                s.id = ClassDef.sanitize(s.id);
                if (s.id.isEmpty() || s.name.isBlank() || !d.trees.containsKey(s.tree)) return;
                if (s.name.length() > 40) s.name = s.name.substring(0, 40);
                if (s.description.length() > 200) s.description = s.description.substring(0, 200);
                s.xpCost = clamp(s.xpCost, 0, 1000);
                s.xpReward = clamp(s.xpReward, 0, 1000);

                // pré-requisito: precisa existir, ser da mesma árvore e não formar ciclo
                SkillDef par = d.skills.get(s.parent);
                if (par == null || !par.tree.equals(s.tree) || s.parent.equals(s.id)) s.parent = "";
                Set<String> seen = new HashSet<>();
                String cur = s.parent;
                while (!cur.isEmpty()) {
                    if (cur.equals(s.id) || !seen.add(cur)) { s.parent = ""; break; }
                    SkillDef n = d.skills.get(cur);
                    cur = n == null ? "" : n.parent;
                }

                SkillDef old = d.skills.get(s.id);
                s.rewards = old != null ? old.rewards : new ArrayList<>(); // itens só pelo baú
                if (!s.classId.isEmpty() && !ClassData.get(p.server).classes.containsKey(s.classId)
                        && !(old != null && old.classId.equals(s.classId))) s.classId = "";
                SkillDef pp = s.parent.isEmpty() ? null : d.skills.get(s.parent);
                if (pp != null && !pp.classId.isEmpty()) s.classId = pp.classId;
                if (!s.classId.isEmpty()) cascadeClass(d, s.id, s.classId);
                d.skills.put(s.id, s);
                d.setDirty();
                SkillManager.syncAll(p.server);
            });
            c.get().setPacketHandled(true);
        }
    }

    public record SDeleteSkill(String id) {
        static void enc(SDeleteSkill m, FriendlyByteBuf b) { b.writeUtf(m.id, 64); }
        static SDeleteSkill dec(FriendlyByteBuf b) { return new SDeleteSkill(b.readUtf(64)); }
        static void handle(SDeleteSkill m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null || !p.hasPermissions(2)) return;
                SkillData d = SkillData.get(p.server);
                SkillDef gone = d.skills.remove(m.id);
                if (gone == null) return;
                // os filhos passam a depender do "avô", mantendo a progressão
                for (SkillDef s : d.skills.values()) if (s.parent.equals(gone.id)) s.parent = gone.parent;
                d.setDirty();
                SkillManager.syncAll(p.server);
            });
            c.get().setPacketHandled(true);
        }
    }

    public record SEditRewards(String id) {
        static void enc(SEditRewards m, FriendlyByteBuf b) { b.writeUtf(m.id, 64); }
        static SEditRewards dec(FriendlyByteBuf b) { return new SEditRewards(b.readUtf(64)); }
        static void handle(SEditRewards m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null || !p.hasPermissions(2)) return;
                SkillDef s = SkillData.get(p.server).skills.get(m.id);
                if (s != null) SkillRewardMenu.open(p, s);
            });
            c.get().setPacketHandled(true);
        }
    }
}
